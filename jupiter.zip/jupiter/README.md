1. pull this repository to your WP installation > wp-content > themes > create a folder and rename it jupiter

2. in terminal cd to jupiter/js

3. RUN :

sudo npm install 

gulp build

#jenkins test 14-10-2016 11:30